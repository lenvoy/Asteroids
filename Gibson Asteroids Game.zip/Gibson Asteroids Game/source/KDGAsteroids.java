import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class KDGAsteroids extends PApplet {

// determines how far beyond the window the screen wraps
int boundary;

Player player;
ArrayList<Bullet> bullets;
ArrayList<Asteroid> asteroids;

// Makes up the top left health gauge
PShape healthBox;
PShape healthBar;
double healthScale;

// Keeps track of the player's score
int score;

// booleans that determine if a key is currently being held down
boolean aKey;
boolean dKey;
boolean wKey;
boolean spaceBar;
boolean shotAlready;

// boolean that changes the game state to game over
boolean gameOver;

PFont font;

// Sets up the game
public void setup()
{
  // Sets the size of the game
  
  boundary = width/20;
  
  // Sets all keys to false at the beginning
  aKey = false;
  dKey = false;
  wKey = false;
  spaceBar = false;
  shotAlready = false;
  
  font = loadFont("FZDX--GB1-4-48.vlw");
  
  // Sets up the health bar
  healthBox = createShape(RECT, 20, 20, width/5, height/20);
  healthBox.setStroke(255);
  healthBox.setFill(false);
  healthBar = createShape(RECT, 0, 0, width/5, height/20);
  healthBar.setStroke(false);
  healthBar.setFill(color(0, 120, 155));
  healthScale = 1;
  
  // Initializes score at 0
  score = 0;
  
  player = new Player(width/50);
  asteroids = new ArrayList<Asteroid>();
  bullets = new ArrayList<Bullet>();
}

// Draws the game, and handles iterative logic
public void draw()
{
  background(0);
  
  // Determines if the game is over, and doesn't continue the game if so
  if(gameOver)
  {
    gameOverDraw();
    return;
  }
  
  // Updates the player using key presses
  player.update(aKey, dKey, wKey);
  
  // Randomly adds an asteroid
  if((int)random(150) == 75 && asteroids.size() < 12)
    addAsteroid();
    
  // Moves and shows all the asteroids
  for(int i = 0; i < asteroids.size(); i++)
  {
    asteroids.get(i).update();
    asteroids.get(i).display();
  }
  
  // Shoots a bullet if the spacebar is pressed and was released since last shot
  if(spaceBar && !shotAlready)
  {
    spaceBar = false;
    shotAlready = true;
    if(bullets.size() < 3)
      bullets.add(new Bullet(player.direction, player.position));
  }
  // Moves, expands, and gets rid of bullets
  for(int i = 0; i < bullets.size(); i++)
  {
    bullets.get(i).update();
    bullets.get(i).display();
    if(bullets.get(i).diedOut())
    {
      bullets.remove(i);
      i--;
    }
  }
  // Shows the player
  player.display();
  
  // Displays the health bar
  pushMatrix();
    translate(20, 20);
    scale((float)healthScale, 1);
    shape(healthBar, 0, 0);
  popMatrix();
  shape(healthBox);
  
  // Shows the score and instructions
  textFont(font, 40);
  text("SCORE: " + score, 40 + width/5, 53);
  textFont(font, 30);
  text("MOVE: A, W, D   SHOOT: SPACE", 20, height - 20);
  
  // Does exactly what it says it does lmao
  checkCollisions();
}

// Method for drawing the game over state
public void gameOverDraw()
{
  textFont(font, 60);
  text("GAME OVER", width/2 - 180, height/2);
  textFont(font, 40);
  text("SCORE: " + score, width/2 - 100, height/2 + 80);
}

// Sets keypresses to true
public void keyPressed()
{
  if(key == 'a' || key == 'A')
    aKey = true;
  else if(key == 'd' || key == 'D')
    dKey = true;
  else if(key == 'w' || key == 'W')
    wKey = true;
  else if(key == ' ')
    spaceBar = true;
}

// sets keypresses to false
public void keyReleased()
{
  if(key == 'a' || key == 'A')
    aKey = false;
  else if(key == 'd' || key == 'D')
    dKey = false;
  else if(key == 'w' || key == 'W')
    wKey = false;
  else if(key == ' ')
    shotAlready = false;
}

// adds an asteroid to the arrayList
public void addAsteroid()
{
  // first, randomizes which edge of the screen it starts at
  float x = 0;
  float y = 0;
  switch((int)random(0, 4))
  {
    case 0:
      x = random(-boundary, width + boundary);
      y = -boundary;
    break;
    case 1:
      x = -boundary;
      y = random(-boundary, height + boundary);
    break;
    case 2:
      x = random(-boundary, width + boundary);
      y = height + boundary;
    break;
    case 3:
      x = width + boundary;
      y = random(-boundary, height + boundary);
    break;
  }
  PVector position = new PVector(x, y);
  
  // determines which direction it will go to target the player
  float rise = (position.y - player.position.y);
  float run = (player.position.x - position.x);
  PVector direction = new PVector(run, rise);
  direction.normalize();
  
  // finally, adds the asteroid
  asteroids.add(new Asteroid(3, width/25, direction, position, true));
}

// Checks for collisions between (bullets + asteroids) and (player + asteroids)
public void checkCollisions()
{
  for(int i1 = 0; i1 < asteroids.size(); i1++)
  {
    double distance;
    // uses the radii of the objects and their distance apart to determine collisions
    
    for(int i2 = 0; i2 < bullets.size(); i2++)
    {
      // checks between bullets and asteroids first
      distance = sqrt(sq(asteroids.get(i1).position.x - bullets.get(i2).position.x) + sq(asteroids.get(i1).position.y - bullets.get(i2).position.y));
      if(distance < bullets.get(i2).radius + asteroids.get(i1).radius)
      {
        bullets.remove(i2);
        i2--;
        // if the asteroid is a big one and is destroyed, creates smaller ones
        if(asteroids.get(i1).original == true)
        {
          float x1 = random(-100, 101);
          float y1 = random(-100, 101);
          PVector direction1 = new PVector(x1, y1);
          PVector direction2 = new PVector(y1, x1);
          direction1.normalize();
          direction2.normalize();
          asteroids.add(new Asteroid(asteroids.get(i1).type, width/50, direction1, new PVector(asteroids.get(i1).position.x, asteroids.get(i1).position.y), false));
          asteroids.add(new Asteroid(asteroids.get(i1).type, width/50, direction2, new PVector(asteroids.get(i1).position.x, asteroids.get(i1).position.y), false));
        }
        asteroids.remove(i1);
        i1--;
        score += 100;
        return;
      }
    }
    
    // checks between player and asteroids second
    distance = sqrt(sq(asteroids.get(i1).position.x - player.position.x) + sq(asteroids.get(i1).position.y - player.position.y));
    if(distance < player.radius + asteroids.get(i1).radius)
    {
      // decrements the player's health if hit
      asteroids.remove(i1);
      i1--;
      healthScale -= .333f;
      if(healthScale < .1f)
        gameOver = true;
      return;
    }
  }
}
class Asteroid
{
  // the two rotating asteroid shapes
  PShape partOne;
  PShape partTwo;
  
  PVector position;
  PVector direction;
  PVector velocity;
  
  double radius;
  double rotation;
  boolean original;
  int type;
  
  Asteroid(int asteroidPicker, double radius, PVector direction, PVector position, boolean original)
  {
    this.radius = radius;
    this.direction = direction;
    this.position = position;
    
    // Sets velocity based on if it's a small or big asteroid
    this.original = original;
    velocity = new PVector(0, 1.5f);
    if(!original)
      velocity.y += .5f;
    rotation = 0.0f;
    
    // creates one of three asteroid shapes randomly
    if(asteroidPicker == 3)
      asteroidPicker = (int)random(3);
    type = asteroidPicker;
    switch(type)
    {
      case 0:
        partOne = createShape();
        partOne.beginShape();
          partOne.vertex((float)(-1.12f*(radius)), (float)radius);
          partOne.vertex((float)(1.12f*(radius)), (float)radius);
          partOne.vertex(0, (float)(-1.12f*(radius)));
        partOne.endShape(CLOSE);
        partTwo = createShape();
        partTwo.beginShape();
          partTwo.vertex((float)(-1.12f*(radius)), (float)radius);
          partTwo.vertex((float)(1.12f*(radius)), (float)radius);
          partTwo.vertex(0, (float)(-1.12f*(radius)));
        partTwo.endShape(CLOSE);
      break;
      case 1:
        partOne = createShape(RECT, (float)(-.75f*(radius)), (float)(-.75f*(radius)), (float)(1.5f*(radius)), (float)(1.5f*(radius)));
        partTwo = createShape(RECT, (float)(-.75f*(radius)), (float)(-.75f*(radius)), (float)(1.5f*(radius)), (float)(1.5f*(radius)));
      break;
      case 2:
        partOne = createShape();
        partOne.beginShape();
          partOne.vertex((float)(-.7265f*(radius)), (float)radius);
          partOne.vertex((float)(.7265f*(radius)), (float)radius);
          partOne.vertex((float)(1.1755f*(radius)), (float)(radius - 1.3819f*(radius)));
          partOne.vertex(0, (float)(-1.236f*(radius)));
          partOne.vertex((float)(-1.1755f*(radius)), (float)(radius - 1.3819f*(radius)));
        partOne.endShape(CLOSE);
        partTwo = createShape();
        partTwo.beginShape();
          partTwo.vertex((float)(-.7265f*(radius)), (float)radius);
          partTwo.vertex((float)(.7265f*(radius)), (float)radius);
          partTwo.vertex((float)(1.1755f*(radius)), (float)(radius - 1.3819f*(radius)));
          partTwo.vertex(0, (float)(-1.236f*(radius)));
          partTwo.vertex((float)(-1.1755f*(radius)), (float)(radius - 1.3819f*(radius)));
        partTwo.endShape(CLOSE);
      break;
    }
    
    partOne.setFill(false);
    partTwo.setFill(false);
    partOne.setStroke(150);
    partTwo.setStroke(150);
  }
  
  // Updates the asteroid
  public void update()
  {
    // Moves the asteroid based on velocity and direction
    position.add(PVector.mult(direction, velocity.y));
    rotation += .5f;
    if(rotation >= 360.0f)
      rotation -= 360.0f;
      
    // wraps the asteroid around the screen
    if(position.x < -boundary)
    {
      position.x = width + boundary;
    }
    else if(position.x > width + boundary)
    {
      position.x = -boundary;
    }
    if(position.y < -boundary)
    {
      position.y = height + boundary;
    }
    else if(position.y > height + boundary)
    {
      position.y = -boundary;
    }
  }
  
  // Draws the asteroid to the screen
  public void display()
  {
    pushMatrix();
      translate(position.x, position.y);
      rotate(radians((float)rotation));
      shape(partOne);
      translate(-position.x, -position.y);
    popMatrix();
    pushMatrix();
      translate(position.x, position.y);
      rotate(radians(-(float)rotation));
      shape(partTwo);
      translate(-position.x, -position.y);
    popMatrix();
  }
}
class Bullet
{
  PVector position;
  PVector direction;
  PVector velocity;
  
  PShape bullet;
  double radius;
  // uses a counter to determine whent the bullet expires
  int counter;
  
  Bullet(PVector direction, PVector position)
  {
    // Uses the direction and position of the player to determine the bullet's
    this.direction = new PVector(direction.x, direction.y);
    this.position = new PVector(position.x, position.y);
    velocity = new PVector(0, 10);
    
    bullet = createShape(ELLIPSE, 0, 0, 10, 10);
    bullet.setFill(false);
    bullet.setStroke(255);
    
    radius = width/200;
    counter = 0;
  }
  
  // Updates the bullet (duh)
  public void update()
  {
    // Moves and wrapes the bullet
    position.add(PVector.mult(direction, -velocity.y));
    if(position.x < -boundary)
    {
      position.x = width + boundary;
    }
    else if(position.x > width + boundary)
    {
      position.x = -boundary;
    }
    if(position.y < -boundary)
    {
      position.y = height + boundary;
    }
    else if(position.y > height + boundary)
    {
      position.y = -boundary;
    }
    
    counter++;
  }
  
  // Draws the bullet
  public void display()
  {
    // Makes the bullet flash colors
    bullet.setStroke(color(random(256), random(256), random(256)));
    // Expands the bullet
    bullet.scale(1.03f);  
    radius = radius * 1.03f;
    
    pushMatrix();
    translate(position.x, position.y);
    shape(bullet);
    translate(-position.x, -position.y);
    popMatrix();
  }
  
  // Kills off the bullet
  public boolean diedOut()
  {
    if(counter > 60)
      return true;
    return false;
  }
}
class Player
{
  PVector position;
  PVector direction;
  PVector velocity;
  PVector acceleration;
  
  PShape player;
  PShape fire;
  
  int radius;
  int maxSpeed;
  double rotation;
  boolean decelerating;
  double decelX;
  double decelY;
  
  Player(int radius)
  {
    this.radius = radius;
    maxSpeed = 7;
    rotation = 90;
    decelerating = false;
    decelX = 0;
    decelY = 0;
    
    // Creates the player
    player = createShape();
    player.beginShape();
    player.noFill();
    player.stroke(255);
    player.vertex(-(radius - radius/4), radius);
    player.vertex(0, -radius);
    player.vertex(radius - radius/4, radius);
    player.endShape(CLOSE);
    
    // Creates the exhaust that shows when accelerating
    fire = createShape();
    fire.beginShape();
    fire.noFill();
    fire.stroke(color(0, 225, 255));
    fire.vertex(-(radius - radius/2), radius);
    fire.vertex(0, radius*2);
    fire.vertex(radius - radius/2, radius);
    fire.endShape(CLOSE);
    
    position = new PVector(width/2, height/2);
    direction = new PVector(0, 1);
    velocity = new PVector(0, 0);
    acceleration = new PVector(0, 0);
  }
  
  // Updates the player
  public void update(boolean aKey, boolean dKey, boolean wKey)
  {
    // rotates the player
    if(aKey)
      rotation -= 5;
    if(dKey)
      rotation += 5;
    
    // Wraps rotation
    if(rotation >= 360)
      rotation -= 360;
    else if(rotation < 0)
      rotation += 360;
    
    // Changes the direction of the player based on its rotation
    if(rotation == 0)
    {
      direction.x = 1;
      direction.y = 0;
    }
    else if(rotation == 90)
    {
      direction.x = 0;
      direction.y = 1;
    }
    else if(rotation == 180)
    {
      direction.x = -1;
      direction.y = 0;
    }
    else if(rotation == 270)
    {
      direction.x = 0;
      direction.y = -1;
    }
    else if(rotation > 270)
    {
      direction.x = (float)((1.0f/90.0f)*(rotation - 270.0f));
      direction.y = (float)(-1.0f + (1.0f/90.0f)*(rotation - 270.0f));
    }
    else if(rotation > 180)
    {
      direction.x = (float)(-1.0f + (1.0f/90.0f)*(rotation - 180.0f));
      direction.y = -(float)((1.0f/90.0f)*(rotation - 180.0f));
    }
    else if(rotation > 90)
    {
      direction.x = -(float)((1/90.0f)*(rotation - 90.0f));
      direction.y = (float)(1.0f - (1.0f/90.0f)*(rotation - 90.0f));
    }
    else
    {
      direction.x = (float)(1.0f - (1.0f/90.0f)*(rotation));
      direction.y = (float)((1.0f/90.0f)*(rotation));
    }
    direction.normalize();
    
    // Uses keyboard input to accelerate the player
    if(wKey)
    {
      decelerating = false;
      decelX = 0;
      decelY = 0;
      acceleration.y = -.15f;
    }
    // Decelerates the player when not moving
    else if(!wKey)
    {
      acceleration.y = 0;
      if(!wKey && velocity.mag() != 0)
      {
        if(!decelerating)
        {
          decelerating = true;
          decelX = velocity.x/40;
          decelY = velocity.y/40;
        }
        velocity.x -= decelX;
        velocity.y -= decelY;
        
        if(velocity.mag() < .1f)
        {
          decelerating = false;
          decelX = 0;
          decelY = 0;
        }
      }
    }
    
    // Changes velocity and moves player based on the velocity
    velocity.add(PVector.mult(direction, acceleration.y));
    velocity.limit(maxSpeed);
    position.add(velocity);
    
    // Wraps the player around the screen
    if(position.x < -boundary)
    {
      position.x = width + boundary;
    }
    else if(position.x > width + boundary)
    {
      position.x = -boundary;
    }
    if(position.y < -boundary)
    {
      position.y = height + boundary;
    }
    else if(position.y > height + boundary)
    {
      position.y = -boundary;
    }
  }
  
  // Draws the player
  public void display()
  {
    // Makes the fire flash blue
    fire.setStroke(color(0, random(256), random(150, 256)));
    pushMatrix();
      translate(position.x, position.y);
      rotate(radians((float)(rotation - 90)));
      // Only draws the exhaust while accelerating
      if(acceleration.y == -.15f)
        shape(fire);
      shape(player);
      translate(-position.x, -position.y);
    popMatrix();
  }
}
  public void settings() {  size(1000, 700); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "KDGAsteroids" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
